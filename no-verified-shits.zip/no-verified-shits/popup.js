const t = document.getElementById("t");
chrome.storage.sync.get({ enabled: true }, (v) => (t.checked = v.enabled));
t.addEventListener("change", () => chrome.storage.sync.set({ enabled: t.checked }));

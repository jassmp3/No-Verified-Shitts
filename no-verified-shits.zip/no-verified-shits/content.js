(() => {
  const PHRASE = /verified resale/i;
  const HIDE_CLASS = "nvs-hidden";
  const MARK = "data-nvs";

  const style = document.createElement("style");
  style.textContent = `.${HIDE_CLASS}{display:none !important;}`;
  document.documentElement.appendChild(style);

  let enabled = true;
  let timer = null;

  // Climb from the matching text up to the full listing row:
  // the largest ancestor that still contains exactly one "Sec ###" listing.
  function findRow(el) {
    const count = (n) => (n.textContent.match(/\bSec\s*\w+/gi) || []).length;
    let row = el;
    let node = el;
    while (node.parentElement && node.parentElement !== document.body) {
      const parent = node.parentElement;
      if (count(parent) > 1) break;
      if (/pay\s*in\s*4|we'?re all in/i.test(parent.textContent) && count(parent) < 1) break;
      node = parent;
      if (count(node) === 1) row = node;
    }
    return row;
  }

  function scan() {
    if (!enabled) return;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (t) =>
        PHRASE.test(t.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT,
    });
    const hits = [];
    while (walker.nextNode()) hits.push(walker.currentNode.parentElement);
    for (const el of hits) {
      if (!el || el.closest(`[${MARK}]`)) continue;
      const row = findRow(el);
      if (!row || !/\bSec\s*\w+/i.test(row.textContent)) continue;
      row.setAttribute(MARK, "1");
      row.classList.add(HIDE_CLASS);
    }
  }

  function restore() {
    document.querySelectorAll(`[${MARK}]`).forEach((n) => {
      n.classList.remove(HIDE_CLASS);
      n.removeAttribute(MARK);
    });
  }

  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(scan, 100);
  }

  function apply() {
    enabled ? scan() : restore();
  }

  try {
    chrome.storage.sync.get({ enabled: true }, (v) => {
      enabled = v.enabled;
      apply();
    });
    chrome.storage.onChanged.addListener((c) => {
      if (c.enabled) {
        enabled = c.enabled.newValue;
        apply();
      }
    });
  } catch (e) {
    scan();
  }

  new MutationObserver(schedule).observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true,
  });
})();
